declare module 'react-native-web-refresh-control';
