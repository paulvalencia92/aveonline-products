import { createStackNavigator } from '@react-navigation/stack';

export default createStackNavigator;
