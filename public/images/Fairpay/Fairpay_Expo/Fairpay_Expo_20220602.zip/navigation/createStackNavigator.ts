import { createNativeStackNavigator } from 'react-native-screens/native-stack';

export default createNativeStackNavigator;
